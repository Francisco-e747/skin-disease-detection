

#.CHECK IT LATER AND FIND A WAY TO COMPUTE IT AND SO ON;----THIS IS THE CODE FOR DRAWING A RECTANGULAR INSIDE DEFINED FACE 
import os
import tensorflow as tf
import numpy as np
import cv2
import json
import pandas as pd
from django.core.files.storage import default_storage
from django.shortcuts import render,redirect
from django.http import JsonResponse
from django.template.loader import render_to_string


from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.conf import settings


#this if for using GRAD-CAM (Gradient weighted class activation mapping) it is used only to highlight the disease area
import tensorflow.keras.backend as K
import matplotlib.pyplot as plt


# Load trained model
model = tf.keras.models.load_model("/Users/mac/Downloads/skin_desease_detection/skin_disease_detection_model.keras")

# Load class labels
with open("/Users/mac/Downloads/skin_desease_detection/class_labels.json", "r") as f:
    class_labels = json.load(f)

# Load disease details from Excel
excel_path = "/Users/mac/Downloads/Diseases.xlsx"
df = pd.read_excel(excel_path)


# Convert DataFrame to a dictionary for faster lookup
disease_info = {}
for _, row in df.iterrows():
    disease_info[row["Disease Name"]] = {
        "cause": row["Cause"],
        "treatment": row["Treatment"],
        "lifestyle_change": row["Lifestyle Change"],
        "skin_care_routine": row["Skin Care Routine"],
        "vitamins": row["Vitamins"]
    }

# Function to process image (resize and normalize)
def process_image(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Error: Could not read image file.")
    
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (128, 128))
    img = img / 255.0
    img = np.expand_dims(img, axis=0)

    return img

# Function to generate Grad-CAM heatmap
def generate_gradcam_heatmap(model, img_array, class_index):
    # Ensure the model is built (with a dummy input shape)
    model.build(input_shape=(None, 128, 128, 3))  # Modify to match input size

    # Get the last convolutional layer (use the correct name from your model)
    last_conv_layer = model.get_layer("conv2d_2")  # Update to your last conv layer

    # Create the Grad-CAM model that outputs both the last conv layer output and the final prediction
    grad_model = tf.keras.models.Model(inputs=model.input, outputs=[last_conv_layer.output, model.output])

    # Start computing the gradients
    with tf.GradientTape() as tape:
        conv_output, predictions = grad_model(img_array)
        loss = predictions[:, class_index]

    # Compute gradients
    grads = tape.gradient(loss, conv_output)

    # Pool gradients and apply them to the convolutional feature maps
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))

    conv_output = conv_output[0]  # Get the actual output from the conv layer
    for i in range(pooled_grads.shape[-1]):
        conv_output[:, :, i] *= pooled_grads[i]

    # Generate the heatmap
    heatmap = np.mean(conv_output, axis=-1)

    # Normalize and return heatmap
    heatmap = np.maximum(heatmap, 0)
    heatmap = heatmap / np.max(heatmap)

    return heatmap




# Function to process image with Grad-CAM and highlight skin area
def process_image_with_highlight(image_path, model):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Error: Could not read image file.")

    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img_resized = cv2.resize(img_rgb, (128, 128))
    img_normalized = img_resized / 255.0
    img_array = np.expand_dims(img_normalized, axis=0)

    prediction = model.predict(img_array)
    predicted_class = np.argmax(prediction, axis=1)[0]

    heatmap = generate_gradcam_heatmap(model, img_array, predicted_class)
    heatmap_resized = cv2.resize(heatmap, (img.shape[1], img.shape[0]))
    heatmap_color = cv2.applyColorMap(np.uint8(255 * heatmap_resized), cv2.COLORMAP_JET)
    superimposed_img = cv2.addWeighted(img, 0.6, heatmap_color, 0.4, 0)

    processed_filename = "processed_" + os.path.basename(image_path)
    processed_path = os.path.join(settings.MEDIA_ROOT, processed_filename)
    cv2.imwrite(processed_path, superimposed_img)

    return os.path.join(settings.MEDIA_URL, processed_filename)

@login_required
def upload_image(request):
    if request.method == 'POST' and request.FILES.get('image'):
        uploaded_file = request.FILES['image']
        file_path = default_storage.save('uploads/' + uploaded_file.name, uploaded_file)
        img_path = default_storage.path(file_path)

        try:
            # Process the image and highlight affected skin regions
            processed_img_url = process_image_with_highlight(img_path, model)

            prediction = model.predict(process_image(img_path))
            predicted_class = np.argmax(prediction, axis=1)[0]

            if str(predicted_class) in class_labels:
                predicted_label = class_labels[str(predicted_class)]
                info = disease_info.get(predicted_label, {})
            else:
                predicted_label = "Unknown Category"
                info = {}

            # Render result page with processed image
            return render(request, 'result.html', {
                "prediction": predicted_label,
                "cause": info.get("cause", "N/A"),
                "treatment": info.get("treatment", "N/A"),
                "lifestyle_change": info.get("lifestyle_change", "N/A"),
                "skin_care_routine": info.get("skin_care_routine", "N/A"),
                "vitamins": info.get("vitamins", "N/A"),
                "processed_image": processed_img_url,  # ✅ This is now correct
            })

        except Exception as e:
            return render(request, 'error.html', {"error_message": str(e)})

    return render(request, 'upload.html')



# User Registration View
def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        confirm_password = request.POST["confirm_password"]

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return redirect("register")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return redirect("register")

        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        messages.success(request, "Account created successfully! Please log in.")
        return redirect("login")

    return render(request, "register.html")

# User Login View
def user_login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Login successful!")
            return redirect("home")  # Redirect to homepage after login
        else:
            messages.error(request, "Invalid username or password!")
            return redirect("login")

    return render(request, "login.html")

# User Logout View
def user_logout(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("home")

from django.shortcuts import render

# Home page view
def home(request):
    return render(request, 'home.html')



"""HOW IT WORKS?"""
'''
The user uploads an image via the form.
The image is saved, processed, and passed to the AI model.
The model predicts the skin disease, and the result is displayed on the page.
'''

print(model.input)

#HERE IS WHERE IT FINISH SO, I WILL CHECK IT AGAIN AND SO ON
#----------------------------------------------------------------------------------------------------------------------------------



#----------------------------------------------------------------------------------------------------------------------------------
#THIS IS THE CODE WE ARE GOING TO USE IN CASE THE ACTUAL CODE IS NOT WORKING

import os
import tensorflow as tf
import numpy as np
import cv2
import json
import pandas as pd
from django.core.files.storage import default_storage
from django.shortcuts import render,redirect
from django.http import JsonResponse
from django.template.loader import render_to_string


from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.conf import settings


#this if for using GRAD-CAM (Gradient weighted class activation mapping) it is used only to highlight the disease area
import tensorflow.keras.backend as K
import matplotlib.pyplot as plt


# Load trained model
model = tf.keras.models.load_model("/Users/mac/Downloads/skin_desease_detection/skin_disease_detection_model.keras")

# Load class labels
with open("/Users/mac/Downloads/skin_desease_detection/class_labels.json", "r") as f:
    class_labels = json.load(f)

# Load disease details from Excel
excel_path = "/Users/mac/Downloads/Diseases.xlsx"
df = pd.read_excel(excel_path)



# Convert DataFrame to a dictionary for faster lookup
disease_info = {}
for _, row in df.iterrows():
    disease_info[row["Disease Name"]] = {
        "cause": row["Cause"],
        "treatment": row["Treatment"],
        "lifestyle_change": row["Lifestyle Change"],
        "skin_care_routine": row["Skin Care Routine"],
        "vitamins": row["Vitamins"]
    }



def process_image(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Error: Could not read image file.")
    
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (128, 128))
    img = img / 255.0
    img = np.expand_dims(img, axis=0)

    return img




def process_image_with_highlight(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Error: Could not read image file.")

    hsv_img = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    lower_skin = np.array([0, 20, 70], dtype=np.uint8)
    upper_skin = np.array([20, 255, 255], dtype=np.uint8)

    skin_mask = cv2.inRange(hsv_img, lower_skin, upper_skin)
    contours, _ = cv2.findContours(skin_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:
        if cv2.contourArea(contour) > 500:
            x, y, w, h = cv2.boundingRect(contour)
            cv2.rectangle(img, (x, y), (x + w, y + h), (0, 255, 0), 2)  # Green border

    # Save processed image in media folder
    processed_filename = "processed_" + os.path.basename(image_path)
    processed_path = os.path.join(settings.MEDIA_ROOT, processed_filename)

    cv2.imwrite(processed_path, img)

    # Return relative URL to be used in templates
    return settings.MEDIA_URL + processed_filename





@login_required
def upload_image(request):
    if request.method == 'POST' and request.FILES.get('image'):
        uploaded_file = request.FILES['image']
        file_path = default_storage.save('uploads/' + uploaded_file.name, uploaded_file)
        img_path = default_storage.path(file_path)

        try:
            # Process the image and highlight affected skin regions
            processed_img_url = process_image_with_highlight(img_path)

            prediction = model.predict(process_image(img_path))
            predicted_class = np.argmax(prediction, axis=1)[0]

            if str(predicted_class) in class_labels:
                predicted_label = class_labels[str(predicted_class)]
                info = disease_info.get(predicted_label, {})
            else:
                predicted_label = "Unknown Category"
                info = {}

            # Render result page with processed image
            return render(request, 'result.html', {
                "prediction": predicted_label,
                "cause": info.get("cause", "N/A"),
                "treatment": info.get("treatment", "N/A"),
                "lifestyle_change": info.get("lifestyle_change", "N/A"),
                "skin_care_routine": info.get("skin_care_routine", "N/A"),
                "vitamins": info.get("vitamins", "N/A"),
                "processed_image": processed_img_url,  # ✅ This is now correct
            })

        except Exception as e:
            return render(request, 'error.html', {"error_message": str(e)})

    return render(request, 'upload.html')



# User Registration View
def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        confirm_password = request.POST["confirm_password"]

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return redirect("register")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return redirect("register")

        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        messages.success(request, "Account created successfully! Please log in.")
        return redirect("login")

    return render(request, "register.html")

# User Login View
def user_login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]

        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            messages.success(request, "Login successful!")
            return redirect("home")  # Redirect to homepage after login
        else:
            messages.error(request, "Invalid username or password!")
            return redirect("login")

    return render(request, "login.html")

# User Logout View
def user_logout(request):
    logout(request)
    messages.success(request, "You have been logged out.")
    return redirect("home")

from django.shortcuts import render

# Home page view
def home(request):
    return render(request, 'home.html')



"""HOW IT WORKS?"""
'''
The user uploads an image via the form.
The image is saved, processed, and passed to the AI model.
The model predicts the skin disease, and the result is displayed on the page.
'''
#--THIS IS WHERE THE CODE FINISH AND THAT IS HOW IS IT AND SO ON
#---------------------------------------------------------------------------------------------------------------------------------

#---------------------------------------------------------------------------------------------------------------------------------
#THIS IS THE TRAINING CODE FOR train_model.py I WILL SAVE IT HERE AND THEN DELETE IT LATER IN CASE THE ACTUAL CODE DOES NOT WORK

import numpy as np
import tensorflow as tf
import pandas as pd
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, GlobalAveragePooling2D, Input
from tensorflow.keras.optimizers import Adam

# Paths to HAM10000 dataset
image_folders = [
    "/Users/mac/Downloads/archive/HAM10000_images_part_1",
    "/Users/mac/Downloads/archive/HAM10000_images_part_2",
    "/Users/mac/Downloads/archive/ISIC2018_Task3_Test_Images"
]
metadata_path = "/Users/mac/Downloads/archive/HAM10000_metadata.csv"

# Paths for sd-198 dataset
sd198_classes_path = "/Users/mac/Downloads/sd-198/classes.txt"
sd198_labels_path = "/Users/mac/Downloads/sd-198/image_class_labels.txt"
sd198_images_folder = "/Users/mac/Downloads/sd-198/images"

# Load metadata for HAM10000
df = pd.read_csv(metadata_path)
label_dict = {disease: idx for idx, disease in enumerate(df["dx"].unique())}

# Load sd-198 class labels
with open(sd198_classes_path, "r") as f:
    sd198_classes = f.read().splitlines()
sd198_label_dict = {class_name: idx for idx, class_name in enumerate(sd198_classes)}

# Set the number of classes (e.g., 7 for HAM10000 + sd-198)
num_classes = len(label_dict) + len(sd198_classes)

# Create a simple CNN model
model = Sequential([
    Conv2D(32, (3, 3), activation='relu', input_shape=(128, 128, 3)),
    MaxPooling2D(pool_size=(2, 2)),
    Conv2D(64, (3, 3), activation='relu'),
    MaxPooling2D(pool_size=(2, 2)),
    Conv2D(128, (3, 3), activation='relu'),
    Flatten(),
    Dense(128, activation='relu'),
    Dropout(0.5),
    Dense(num_classes, activation='softmax')
])

# Compile the model
model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])

# Function to load batches for training
def load_batch(batch_idx):
    X_batch = np.load(f"X_batch_{batch_idx}.npy")
    y_batch = np.load(f"y_batch_{batch_idx}.npy")
    return X_batch, y_batch

# Initialize batch index
batch_idx = 0
# List to accumulate data across batches
X_all = []
y_all = []

# Load all batches
while True:
    try:
        X_batch, y_batch = load_batch(batch_idx)
        X_all.append(X_batch)
        y_all.append(y_batch)
        batch_idx += 1
    except FileNotFoundError:
        print(f"Finished loading all batches. Total {batch_idx} batches.")
        break

# Convert list to numpy array
X_all = np.concatenate(X_all, axis=0)
y_all = np.concatenate(y_all, axis=0)

# Split the data into training and validation sets (80% training, 20% validation)
from sklearn.model_selection import train_test_split
X_train, X_val, y_train, y_val = train_test_split(X_all, y_all, test_size=0.2, stratify=y_all, random_state=42)

# Train the model
model.fit(X_train, y_train, batch_size=32, epochs=10, validation_data=(X_val, y_val))

# Save the model after training
model.save('skin_disease_detection_model.keras')



"""THIS IS HOW IT WORKS"""
'''
Load the Batches: Instead of loading just one batch at a time, we load all the batches (X_batch_0.npy to X_batch_5.npy and y_batch_0.npy to y_batch_5.npy), accumulate them in lists, and then concatenate them into arrays (X_all, y_all).
Data Splitting: The data is split into training and validation sets using train_test_split from scikit-learn, with 80% of the data used for training and 20% for validation.
Model Creation: The code creates a simple CNN (Convolutional Neural Network) for training. You can customize the architecture based on your needs.
Batch Training: The training loop loads one batch at a time using model.fit(). It processes until all batches are exhausted.
Model Saving: After training, the model is saved as skin_disease_detection_model.h5 for future use.

'''

#------------------------------------------------------------------------------------------------------------------------------------
#--I will delete the ski_disease_detection_model.keras but i will add it again in case this new approach does not work.

#--------------------------------------------------------------------------------------------------------------------------------------
#HERE I WILL ADD THE UPLOAD IMAGE IN CASE I WANT TO MODIFY IT LATER AND SO ON

def upload_image(request):
    if request.method == 'POST' and request.FILES.get('image'):
        uploaded_file = request.FILES['image']
        file_path = default_storage.save('uploads/' + uploaded_file.name, uploaded_file)
        img_path = default_storage.path(file_path)

        try:
            # Process the image and highlight affected skin regions
            processed_img_url = process_image_with_highlight(img_path, model)

            prediction = model.predict(process_image(img_path))
            predicted_class = np.argmax(prediction, axis=1)[0]

            if str(predicted_class) in class_labels:
                predicted_label = class_labels[str(predicted_class)]
                info = disease_info.get(predicted_label, {})
            else:
                predicted_label = "Unknown Category"
                info = {}

            # Render result page with processed image
            return render(request, 'result.html', {
                "prediction": predicted_label,
                "cause": info.get("cause", "N/A"),
                "treatment": info.get("treatment", "N/A"),
                "lifestyle_change": info.get("lifestyle_change", "N/A"),
                "skin_care_routine": info.get("skin_care_routine", "N/A"),
                "vitamins": info.get("vitamins", "N/A"),
                "processed_image": processed_img_url,  # ✅ This is now correct
            })

        except Exception as e:
            return render(request, 'error.html', {"error_message": str(e)})

    return render(request, 'upload.html')







