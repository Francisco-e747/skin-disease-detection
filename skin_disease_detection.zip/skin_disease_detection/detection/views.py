

#.CHECK IT LATER AND FIND A WAY TO COMPUTE IT AND SO ON;
import os
import tensorflow as tf
import numpy as np
import cv2
import json
import pandas as pd
from django.core.files.storage import default_storage
from django.shortcuts import render,redirect
from django.http import JsonResponse
from django.template.loader import render_to_string

from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.conf import settings


#this if for using GRAD-CAM (Gradient weighted class activation mapping) it is used only to highlight the disease area
import tensorflow.keras.backend as K
import matplotlib.pyplot as plt


# Load trained model
model = tf.keras.models.load_model("/Users/mac/Downloads/skin_desease_detection/skin_disease_detection_model.keras")

# Load class labels
with open("/Users/mac/Downloads/skin_desease_detection/class_labels.json", "r") as f:
    class_labels = json.load(f)

# Load disease details from Excel
excel_path = "/Users/mac/Downloads/Diseases.xlsx"
df = pd.read_excel(excel_path)

def get_disease_info(disease_name):
    """Retrieve disease details from the Excel file."""
    info = df[df["Disease Name"] == disease_name].to_dict(orient="records")
    return info[0] if info else {}


# Convert DataFrame to a dictionary for faster lookup
disease_info = {}
for _, row in df.iterrows():
    disease_info[row["Disease Name"]] = {
        "cause": row["Cause"],
        "treatment": row["Treatment"],
        "lifestyle_change": row["Lifestyle Change"],
        "skin_care_routine": row["Skin Care Routine"],
        "vitamins": row["Vitamins"]
    }

# Function to process image (resize and normalize)
def process_image(image_path):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Error: Could not read image file.")
    
    img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img = cv2.resize(img, (128, 128))
    img = img / 255.0
    img = np.expand_dims(img, axis=0)

    return img


# Example function to generate Grad-CAM heatmap
import tensorflow as tf
import numpy as np

def generate_gradcam_heatmap(model, img_array, class_index):
    # Ensure the model has been called at least once
    _ = model.predict(np.zeros((1, 128, 128, 3)))

    # Get the correct last conv layer
    last_conv_layer = model.get_layer("conv2d_2")  # Update this to match your model
    grad_model = tf.keras.models.Model(
        inputs=model.input, 
        outputs=[last_conv_layer.output, model.output]
    )

    with tf.GradientTape() as tape:
        conv_output, predictions = grad_model(img_array)
        loss = predictions[:, class_index]

    # Compute gradients
    grads = tape.gradient(loss, conv_output)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))

    # Multiply the conv_output by pooled_grads without modifying tensors in-place
    conv_output = conv_output[0]  # Remove batch dimension
    conv_output = tf.transpose(conv_output, perm=[2, 0, 1])  # Reorder dimensions to [filters, height, width]
    conv_output = tf.multiply(conv_output, pooled_grads[:, tf.newaxis, tf.newaxis])  # Multiply per filter
    conv_output = tf.transpose(conv_output, perm=[1, 2, 0])  # Restore original shape

    # Compute heatmap
    heatmap = tf.reduce_mean(conv_output, axis=-1)
    heatmap = tf.maximum(heatmap, 0)  # Ensure non-negative values
    heatmap /= tf.reduce_max(heatmap) + tf.keras.backend.epsilon()  # Normalize

    return heatmap.numpy()  # Convert to NumPy array for further processing



# Function to process image with Grad-CAM and highlight skin area
def process_image_with_highlight(image_path, model):
    img = cv2.imread(image_path)
    if img is None:
        raise ValueError("Error: Could not read image file.")

    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
    img_resized = cv2.resize(img_rgb, (128, 128))
    img_normalized = img_resized / 255.0
    img_array = np.expand_dims(img_normalized, axis=0)

    prediction = model.predict(img_array)
    predicted_class = np.argmax(prediction, axis=1)[0]

    heatmap = generate_gradcam_heatmap(model, img_array, predicted_class)
    heatmap_resized = cv2.resize(heatmap, (img.shape[1], img.shape[0]))
    heatmap_color = cv2.applyColorMap(np.uint8(255 * heatmap_resized), cv2.COLORMAP_JET)
    superimposed_img = cv2.addWeighted(img, 0.6, heatmap_color, 0.4, 0)

    processed_filename = "processed_" + os.path.basename(image_path)
    processed_path = os.path.join(settings.MEDIA_ROOT, processed_filename)
    cv2.imwrite(processed_path, superimposed_img)

    return os.path.join(settings.MEDIA_URL, processed_filename)

@login_required
def upload_image(request):
    if request.method == "POST" and request.FILES.get("image"):
        image_file = request.FILES["image"]

        # Save uploaded image
        upload_dir = os.path.join(settings.MEDIA_ROOT, "uploads")
        os.makedirs(upload_dir, exist_ok=True)
        file_path = os.path.join(upload_dir, image_file.name)

        with default_storage.open(file_path, "wb+") as destination:
            for chunk in image_file.chunks():
                destination.write(chunk)

        # Load and preprocess the image
        img = cv2.imread(file_path)
        img = cv2.resize(img, (128, 128))
        img_array = np.expand_dims(img / 255.0, axis=0)  # Normalize

        # Make prediction
        prediction = model.predict(img_array)
        predicted_class = prediction.argmax()
        predicted_label = class_labels.get(str(predicted_class), f"Unknown Class {predicted_class}")

        # Retrieve disease info
        info = get_disease_info(predicted_label)

        # Generate Grad-CAM heatmap
        heatmap = generate_gradcam_heatmap(model, img_array, predicted_class)

        # Apply heatmap to the original image
        heatmap = cv2.resize(heatmap, (img.shape[1], img.shape[0]))  # Resize to original
        heatmap = np.uint8(255 * heatmap)  # Convert to 0-255 scale
        heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)  # Apply color mapping
        processed_img = cv2.addWeighted(img, 0.7, heatmap, 0.3, 0)  # Overlay heatmap

        # Save the processed image
        processed_dir = os.path.join(settings.MEDIA_ROOT, "processed")
        os.makedirs(processed_dir, exist_ok=True)
        processed_path = os.path.join(processed_dir, "processed_" + image_file.name)
        cv2.imwrite(processed_path, processed_img)

        # Get media URLs for the template
        unprocessed_img_url = os.path.join(settings.MEDIA_URL, "uploads", image_file.name)
        processed_img_url = os.path.join(settings.MEDIA_URL, "processed", "processed_" + image_file.name)

        # Render result page with all details
        return render(request, "result.html", {
            "prediction": predicted_label,
            "cause": info.get("Cause", "N/A"),
            "treatment": info.get("Treatment", "N/A"),
            "lifestyle_change": info.get("Lifestyle Change", "N/A"),
            "skin_care_routine": info.get("Skin Care Routine", "N/A"),
            "vitamins": info.get("Vitamins", "N/A"),
            "unprocessed_image": unprocessed_img_url,
            "processed_image": processed_img_url
        })

    return render(request, "upload.html", {"error": "Invalid request"})

# User Registration View
def register(request):
    if request.method == "POST":
        username = request.POST["username"]
        email = request.POST["email"]
        password = request.POST["password"]
        confirm_password = request.POST["confirm_password"]

        if password != confirm_password:
            messages.error(request, "Passwords do not match!")
            return redirect("register")

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken!")
            return redirect("register")

        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        messages.success(request, "Account created successfully! Please log in.")
        return redirect("login")

    return render(request, "register.html")

# User Login View
def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)  # Log the user in
            return redirect('dashboard')  # Redirect to the dashboard after login
        else:
            # Return an error message if login fails
            return render(request, 'login.html', {'error': 'Invalid credentials'})

    return render(request, 'login.html')


# User Logout View
def user_logout(request):
    logout(request)
    return redirect('login')  # Redirect to login page after logout
from django.shortcuts import render

# Home page view
def home(request):
    return render(request, 'home.html')

@login_required  # Ensure the user is logged in
def dashboard(request):
    return render(request, 'dashboard.html')
"""
@login_required
def next_intermediate(request):
    return render(request, 'next_intermediate.html')
"""
@login_required
def upload(request):
    return render(request, 'upload.html')




"""HOW IT WORKS?"""
'''
The user uploads an image via the form.
The image is saved, processed, and passed to the AI model.
The model predicts the skin disease, and the result is displayed on the page.
'''

#asi es como lo hici