# urls.py
from django.urls import path
from .views import upload_image,register, user_login, user_logout,home,dashboard

urlpatterns = [
    path('',home, name="home"),
    path("register/", register, name="register"),
    path("login/", user_login, name="login"),
    path('dashboard/', dashboard, name='dashboard'),
    #path('next/', next_intermediate, name='next_intermediate'),
    path("logout/", user_logout, name="logout"),
    path('upload/',upload_image, name='upload'),
]


