
"""
import tensorflow as tf
from tensorflow.keras import layers, models
import numpy as np
import matplotlib.pyplot as plt

# Build a simple CNN model
model = models.Sequential([
    layers.Conv2D(32, (3, 3), activation='relu', input_shape=(128, 128, 3)),
    layers.MaxPooling2D((2, 2)),
    layers.Conv2D(64, (3, 3), activation='relu'),
    layers.MaxPooling2D((2, 2)),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(10, activation='softmax')  # Assume 10 classes
])

# Compile the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Create a random image (numPy array)
image = np.random.random((1, 128, 128, 3))  # Batch size of 1, 128x128 image with 3 channels (RGB)

# Ensure the image is a TensorFlow tensor
image_tensor = tf.convert_to_tensor(image, dtype=tf.float32)

# Generate Grad-CAM heatmap function
def generate_gradcam_heatmap(model, image, class_index):
    # Ensure model is properly built by passing a dummy input (if needed)
    if not model.built:
        model.build(input_shape=(None, 128, 128, 3))  # Build model if it isn't built

    # Get the last convolutional layer and the model's output
    last_conv_layer = model.get_layer(index=-4)  # Last convolutional layer
    grad_model = tf.keras.models.Model(inputs=[model.inputs], outputs=[last_conv_layer.output, model.outputs])

    with tf.GradientTape() as tape:
        tape.watch(image)
        conv_outputs, predictions = grad_model(image)
        predictions = tf.convert_to_tensor(predictions)  # Ensure it's a tensor
        loss = predictions[:, class_index]

    grads = tape.gradient(loss, conv_outputs)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))  # Pool gradients across spatial dimensions
    heatmap = tf.reduce_mean(conv_outputs * pooled_grads, axis=-1)  # Compute weighted sum of activations
    heatmap = tf.maximum(heatmap, 0)  # ReLU to discard negative values
    heatmap /= tf.reduce_max(heatmap)  # Normalize to [0, 1]
    return heatmap

# Try generating the heatmap for class 0
heatmap = generate_gradcam_heatmap(model, image_tensor, class_index=0)

# Visualize the heatmap
plt.matshow(heatmap[0])  # Remove batch dimension for visualization
plt.show()
"
"""""
import tensorflow as tf
from tensorflow.keras import layers, models
import numpy as np
import matplotlib.pyplot as plt

# Define the input layer explicitly
inputs = tf.keras.Input(shape=(128, 128, 3))

# Define the layers explicitly in a functional way
x = layers.Conv2D(32, (3, 3), activation='relu')(inputs)
x = layers.MaxPooling2D((2, 2))(x)
x = layers.Conv2D(64, (3, 3), activation='relu')(x)
x = layers.MaxPooling2D((2, 2))(x)
x = layers.Flatten()(x)
x = layers.Dense(64, activation='relu')(x)
outputs = layers.Dense(10, activation='softmax')(x)  # Assume 10 classes

# Create the model using the functional API
model = models.Model(inputs=inputs, outputs=outputs)

# Compile the model
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Create a random image (NumPy array)
image = np.random.random((1, 128, 128, 3))  # Batch size of 1, 128x128 image with 3 channels (RGB)

# Ensure the image is a TensorFlow tensor
image_tensor = tf.convert_to_tensor(image, dtype=tf.float32)

# Generate Grad-CAM heatmap function
def generate_gradcam_heatmap(model, image, class_index):
    # Get the last convolutional layer and the model's output
    last_conv_layer = model.get_layer(index=-4)  # Last convolutional layer
    grad_model = tf.keras.models.Model(inputs=[model.input], outputs=[last_conv_layer.output, model.output])

    with tf.GradientTape() as tape:
        tape.watch(image)
        conv_outputs, predictions = grad_model(image)
        predictions = tf.convert_to_tensor(predictions)  # Ensure it's a tensor
        loss = predictions[:, class_index]

    grads = tape.gradient(loss, conv_outputs)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))  # Pool gradients across spatial dimensions
    heatmap = tf.reduce_mean(conv_outputs * pooled_grads, axis=-1)  # Compute weighted sum of activations
    heatmap = tf.maximum(heatmap, 0)  # ReLU to discard negative values
    heatmap /= tf.reduce_max(heatmap)  # Normalize to [0, 1]
    return heatmap

# Try generating the heatmap for class 0
heatmap = generate_gradcam_heatmap(model, image_tensor, class_index=0)

# Visualize the heatmap
plt.matshow(heatmap[0])  # Remove batch dimension for visualization
plt.show()





#check it then later
def user_login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]

        # Authenticate user
        user = authenticate(request, username=username, password=password)

        if user is not None:
            # Log the user in
            login(request, user)
            messages.success(request, "Login successful!")
            
            # Redirect to the upload page (upload.html)
            return redirect('dashboard')  # Replace 'upload' with the correct URL name for your upload page
        else:
            messages.error(request, "Invalid username or password!")  # Display error message
            return redirect('login')  # Stay on login page if authentication fails

    return render(request, "login.html")