import os
import pandas as pd
import numpy as np
import cv2
from tensorflow.keras.utils import to_categorical
from tqdm import tqdm

# Paths to HAM10000 dataset
image_folders = [
    "/Users/mac/Downloads/archive/HAM10000_images_part_1",
    "/Users/mac/Downloads/archive/HAM10000_images_part_2",
    "/Users/mac/Downloads/archive/ISIC2018_Task3_Test_Images"
]
metadata_path = "/Users/mac/Downloads/archive/HAM10000_metadata.csv"

# Paths for sd-198 dataset
sd198_classes_path = "/Users/mac/Downloads/sd-198/classes.txt"
sd198_labels_path = "/Users/mac/Downloads/sd-198/image_class_labels.txt"
sd198_images_folder = "/Users/mac/Downloads/sd-198/images"

# Image processing settings
IMG_SIZE = (128, 128)  # Reduce image size for efficiency
BATCH_SIZE = 2000  # Process 2000 images at a time

# Load metadata for HAM10000
df = pd.read_csv(metadata_path)

# Create label dictionary for HAM10000 dataset
image_labels = dict(zip(df["image_id"], df["dx"]))  # 'dx' column contains disease labels
label_dict = {disease: idx for idx, disease in enumerate(df["dx"].unique())}

# Load sd-198 class labels
with open(sd198_classes_path, "r") as f:
    sd198_classes = f.read().splitlines()
sd198_label_dict = {class_name: idx for idx, class_name in enumerate(sd198_classes)}

# Load sd-198 image-class mappings
sd198_image_labels = {}
with open(sd198_labels_path, "r") as f:
    lines = f.read().splitlines()
    for line in lines:
        img_name, class_index = line.split()  # Assuming space-separated
        class_index = int(class_index) - 1  # Convert to zero-based index
        sd198_image_labels[img_name] = class_index

# Function to process and save batch
def process_and_save_batch(X, y, batch_idx):
    """Converts list to NumPy arrays, saves batch, and clears memory."""
    X = np.array(X, dtype=np.float32)
    y = to_categorical(y, num_classes=len(label_dict) + len(sd198_classes))

    np.save(f"X_batch_{batch_idx}.npy", X)
    np.save(f"y_batch_{batch_idx}.npy", y)

    print(f"✅ Saved batch {batch_idx} with {len(X)} images")
    return [], []  # Reset memory

X, y = [], []
batch_idx = 0

# Process HAM10000 images
for folder in image_folders:
    for img_file in tqdm(os.listdir(folder), desc=f"Processing {folder}"):
        img_id = os.path.splitext(img_file)[0]  # Remove file extension
        img_path = os.path.join(folder, img_file)

        if img_id in image_labels:
            img = cv2.imread(img_path)
            if img is None:
                continue  # Skip corrupted images
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img = cv2.resize(img, IMG_SIZE)
            img = img / 255.0  # Normalize

            X.append(img)
            y.append(label_dict[image_labels[img_id]])

            if len(X) >= BATCH_SIZE:
                X, y = process_and_save_batch(X, y, batch_idx)
                batch_idx += 1

# Process sd-198 images
for img_name, label in sd198_image_labels.items():
    img_path = os.path.join(sd198_images_folder, img_name)

    if os.path.exists(img_path):
        img = cv2.imread(img_path)
        if img is None:
            continue  # Skip corrupted images
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, IMG_SIZE)
        img = img / 255.0  # Normalize

        X.append(img)
        y.append(label)

        if len(X) >= BATCH_SIZE:
            X, y = process_and_save_batch(X, y, batch_idx)
            batch_idx += 1

# Save the remaining images
if X:
    process_and_save_batch(X, y, batch_idx)

print("✅ Dataset preprocessing complete!")

"""KEY POINT IN THE SCRIPT"""
'''
Loads and processes both datasets (HAM10000 and sd-198).
Merges them into one dataset while maintaining their unique labels.
Resizes images to 224x224 and normalizes pixel values to be between 0 and 1.
Creates a unified label dictionary that combines both HAM10000 and sd-198.
Splits the dataset into training and validation sets.

'''

"""AFTER I RUN THIS CODE IT WILL GENERATE DIFFERENT BATCHES WITH .npy FILE"""