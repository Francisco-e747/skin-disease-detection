import numpy as np
import tensorflow as tf
import pandas as pd
from tensorflow.keras.layers import Conv2D, MaxPooling2D, Flatten, Dense, Dropout, Input
from tensorflow.keras.optimizers import Adam
from tensorflow.keras import models


# Paths to HAM10000 dataset
image_folders = [
    "/Users/mac/Downloads/archive/HAM10000_images_part_1",
    "/Users/mac/Downloads/archive/HAM10000_images_part_2",
    "/Users/mac/Downloads/archive/ISIC2018_Task3_Test_Images"
]
metadata_path = "/Users/mac/Downloads/archive/HAM10000_metadata.csv"

# Paths for sd-198 dataset
sd198_classes_path = "/Users/mac/Downloads/sd-198/classes.txt"
sd198_labels_path = "/Users/mac/Downloads/sd-198/image_class_labels.txt"
sd198_images_folder = "/Users/mac/Downloads/sd-198/images"

# Load metadata for HAM10000
df = pd.read_csv(metadata_path)
label_dict = {disease: idx for idx, disease in enumerate(df["dx"].unique())}

# Load sd-198 class labels
with open(sd198_classes_path, "r") as f:
    sd198_classes = f.read().splitlines()
sd198_label_dict = {class_name: idx for idx, class_name in enumerate(sd198_classes)}

# Set the number of classes (e.g., 7 for HAM10000 + sd-198)
num_classes = len(label_dict) + len(sd198_classes)

# Define the input layer (this ensures we're using the Functional API)
inputs = Input(shape=(128, 128, 3))  # Input tensor for 128x128 RGB images

# Build the CNN layers (same as your original architecture)
x = Conv2D(32, (3, 3), activation='relu')(inputs)
x = MaxPooling2D(pool_size=(2, 2))(x)
x = Conv2D(64, (3, 3), activation='relu')(x)
x = MaxPooling2D(pool_size=(2, 2))(x)
x = Conv2D(128, (3, 3), activation='relu')(x)
x = Flatten()(x)
x = Dense(128, activation='relu')(x)
x = Dropout(0.5)(x)
outputs = Dense(num_classes, activation='softmax')(x)

# Create the model using the Functional API
model = models.Model(inputs=inputs, outputs=outputs)

# Compile the model
model.compile(optimizer=Adam(), loss='categorical_crossentropy', metrics=['accuracy'])

# Function to load batches for training
def load_batch(batch_idx):
    X_batch = np.load(f"X_batch_{batch_idx}.npy")
    y_batch = np.load(f"y_batch_{batch_idx}.npy")
    return X_batch, y_batch

# Initialize batch index
batch_idx = 0
# List to accumulate data across batches
X_all = []
y_all = []

# Load all batches
while True:
    try:
        X_batch, y_batch = load_batch(batch_idx)
        X_all.append(X_batch)
        y_all.append(y_batch)
        batch_idx += 1
    except FileNotFoundError:
        print(f"Finished loading all batches. Total {batch_idx} batches.")
        break

# Convert list to numpy array
X_all = np.concatenate(X_all, axis=0)
y_all = np.concatenate(y_all, axis=0)

# Split the data into training and validation sets (80% training, 20% validation)
from sklearn.model_selection import train_test_split
X_train, X_val, y_train, y_val = train_test_split(X_all, y_all, test_size=0.2, stratify=y_all, random_state=42)

# Train the model
model.fit(X_train, y_train, batch_size=32, epochs=10, validation_data=(X_val, y_val))

# Save the model after training
model.save('skin_disease_detection_model.keras')






"""THIS IS HOW IT WORKS"""
'''
Load the Batches: Instead of loading just one batch at a time, we load all the batches (X_batch_0.npy to X_batch_5.npy and y_batch_0.npy to y_batch_5.npy), accumulate them in lists, and then concatenate them into arrays (X_all, y_all).
Data Splitting: The data is split into training and validation sets using train_test_split from scikit-learn, with 80% of the data used for training and 20% for validation.
Model Creation: The code creates a simple CNN (Convolutional Neural Network) for training. You can customize the architecture based on your needs.
Batch Training: The training loop loads one batch at a time using model.fit(). It processes until all batches are exhausted.
Model Saving: After training, the model is saved as skin_disease_detection_model.h5 for future use.

'''


